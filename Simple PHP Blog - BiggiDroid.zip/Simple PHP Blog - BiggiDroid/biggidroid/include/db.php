<?php
$localhost = "localhost";
$username = "root";
$password = "";
$database = "blog";

$con = mysqli_connect($localhost, $username, $password, $database) or die();

?>